import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class Manager
{
	public static void main(String[] args) throws Exception
	{
		Class.forName("com.mysql.jdbc.Driver");
		Connection con = DriverManager.getConnection(
				"jdbc:mysql://localhost:3306/apple", "root", "password");
		Statement stmt=con.createStatement();
		//String sql="create table tab1(id int,name varchar(40))";
		String sql="insert into tab1 values(23,'abc')";
		stmt.executeUpdate(sql);
		System.out.println("done");
	}
}
