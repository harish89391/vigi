package com.nik;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Statement;
public class Manager1
{
	public static void main(String[] args) throws Exception
	{
		Connection con = Util.getconnection();
		PreparedStatement pstmt = con.prepareStatement("create table nik101 (id int,name varchar(20))");
        pstmt.execute();
        
	    
		System.out.println("done");
	}
}
